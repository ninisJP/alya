from django.apps import AppConfig


class EmployeeApiConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'employee_api'

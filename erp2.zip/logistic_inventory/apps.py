from django.apps import AppConfig


class LogisticInventoryConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'logistic_inventory'

from django.apps import AppConfig


class AccountingOrderSalesConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'accounting_order_sales'
